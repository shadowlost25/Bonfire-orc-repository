This archive is for those who wish to play around with OF without downloading Xhor.

Instructions on to use OF are available on the wiki page here: https://hogswilds-bonfire.fandom.com/wiki/Orc_Follower#How_to_use_-_For_NPC_Makers
