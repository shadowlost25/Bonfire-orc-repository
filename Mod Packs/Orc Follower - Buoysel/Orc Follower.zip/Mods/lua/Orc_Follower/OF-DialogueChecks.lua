--[[
    Script for controlling the appearance of dialogue based commands ("Follow, Wait Here, etc")
]]

function canFollow()
    orc.retbool = false
    local validStates = {
        ["DISMISSED"] = "DISMISSED", 
        ["WAITING"] = "WAITING", 
        ["RELAXING"] = "RELAXING"
    }
    orc.retbool = validStates[orc.itemflagstring("OF-FollowState")] ~= nil
end

function canWait()
    orc.retbool = false
    local validStates = {
        ["FOLLOWING"] = "FOLLOWING", 
        ["RELAXING"] = "RELAXING"
    }
    orc.retbool = validStates[orc.itemflagstring("OF-FollowState")] ~= nil
end

function canRelax()
    orc.retbool = false
    local validStates = {
        ["FOLLOWING"] = "FOLLOWING", 
        ["WAITING"] = "WAITING"
    }
    orc.retbool = validStates[orc.itemflagstring("OF-FollowState")] ~= nil
end 

function canDismiss()
    orc.retbool = false
    local validStates = {
        ["FOLLOWING"] = "FOLLOWING", 
        ["WAITING"] = "WAITING", 
        ["RELAXING"] = "RELAXING"
    }
    if not orc.hasitemflag("OF-" .. orc.orcname .. "-OrgSpawn", "@any") then 
        orc.retbool = false
    else 
        orc.retbool = validStates[orc.itemflagstring("OF-FollowState")] ~= nil
    end
end

function isRelaxingOrDismissed()
    orc.retbool = false
    local validStates = {
        ["RELAXING"] = "RELAXING",
        ["DISMISSED"] = "DISMISSED"
    }
    orc.retbool = validStates[orc.itemflagstring("OF-FollowState")] ~= nil
end

function canFuse()

    orc.retbool = false

    --Hide the "Fuse" option if Bolt's quest is in any state before Alchemy6
    --But show it anyway if Bolt is corrupted

    local bolt = orc.game.orcfromcommandname("Bolt")
    local player = orc.game.orcfromcommandname("@playername")

    local boltQuestState = {
        [""] = true, ["1"] = true, ["workplacegood 0"] = true,
        ["workplacegood 2"] = true, ["workplacegood -4"] = true,
        ["workplacegood 5"] = true, ["alchemy1"] = true,
        ["alchemy2"] = true, ["alchemy3"] = true,
        ["alchemy4"] = true, ["alchemy5"] = true
    }

    -- Bolt is currently in the Outback, presumably, or he is available in this scene
    if bolt ~= nil then 

        -- If Bolt is corrupted, grant the option to fuse anyway
        if bolt.corruption > 0 then 
            player.setitemflag("OF-CanSeeFuseOption", "1")
        
        -- Else, check the flag to see if the player is eligible for fusion.
        elseif not boltQuestState[player.itemflagstring(string.lower("BQID_Bolt"))] then 
            player.setitemflag("OF-CanSeeFuseOption", "1")
        else
            player.setitemflag("OF-CanSeeFuseOption", "0")
        end


    -- Bolt is either at the Inn, fused with the player, or somewhere else
    else 

        -- If access to fuse was already granted, don't remove it again
        if player.ifitemflag("OF-CanSeeFuseOption", "1") then 
            --return
        -- Else, try checking the flag again
        elseif not boltQuestState[string.lower(player.itemflagstring(string.lower("BQID_Bolt")))] then 
            player.setitemflag("OF-CanSeeFuseOption", "1")
        else 
            player.setitemflag("OF-CanSeeFuseOption", "0")
        end
    end

    orc.retbool = player.ifitemflag("OF-CanSeeFuseOption", "1")

end