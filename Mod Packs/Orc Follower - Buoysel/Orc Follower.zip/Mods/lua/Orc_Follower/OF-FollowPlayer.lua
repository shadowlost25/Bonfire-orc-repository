--[[
    This orc will follow the player around. They will also
    react to any sex the player is having either by fapping
    by themselves, or by having sex with other followers.
]]

local player = orc.game.orcfromcommandname("@playername")

--Shorthand
local SCRIPT_NAME = "Orc_Follower/OF-FollowPlayer"

--Follow Range
local FOLLOW_RANGE = 5
local followOffset = math.random() + math.random(-1.5,1.5)
local currentDistance = 0
local walkTimeout = 5 --Some orc can get stuck because of unexpected asset placement

--If the player is having sex, attempt to have sex with another follower
local SEX_ATTEMPTS_MAX = 3
local sexAttempts = 0

function startFollowing() 
    orc.consolecommand("forceanim Armature|Idle1")
    orc.setitemflag("OF-FollowState", "FOLLOWING")
    orc.luaiterator(SCRIPT_NAME, "follow", orc.infinity)
    OFDebug("startFollowing", "follow iterator started.")
end 

function stopFollowing() 

    orc.fapstop()
    orc.endsex()
    orc.walk2clear()
    orc.remiterators(SCRIPT_NAME, "follow")
    OFDebug("stopFollowing", "follow iterator stopped.")

end

function follow()

    -- If the orc isn't actively following the player, then don't run this function.
    if not orc.ifitemflag("OF-FollowState", "FOLLOWING") then 
        return
    end

    --Make sure the player exists in the scene.
    if player == nil then 
        OFDebug("checkPlayer", "Player not found, attempting to find them.")
        player = orc.game.orcfromcommandname("@playername")
        return
    end

    --If the player moves away from the follower, make the follower start walking
    currentDistance = orc.game.distancebetweenorcs(orc,player)
    if  currentDistance > FOLLOW_RANGE or
        currentDistance > (FOLLOW_RANGE + followOffset) then

        --...unless caught by a genie.
        if influencedByGenie() then 
            return 
        else 
            cancelActions()
            walkToPlayer()
        end
        
    else 
        --Kill the walking script so the orc doesn't slingshot past the player
        if orc.busywalking then
            orc.walk2clear()
        end 

        -- if player.issexing or player.isfapping then 
            reactToSex()
        -- else
            cancelActions()
        -- end
    end

    if player.isairborne and not orc.isairborne then 
        
        --[[Orcs can get stuck if they're jumping during the quick grow animation, and
          unfreezenode doens't seem to fix it. So just stop jumping all together
          if they're about to change.
        ]]
        if orc.corruption < 3 then
            orc.fapstop() 
            orc.jump(1)
        end
    end

end

function walkToPlayer() 

    --Attempt to allow the orc to walk again if they had sex at some point
    if not orc.busywalking then 
        orc.consolecommand("unfreezenode")
    end

    if currentDistance > 50 then 
        orc.consolecommand("tp2orcquiet @playername")
    elseif currentDistance > (FOLLOW_RANGE * 5) then 
        walkToPlayerOffset(player.positionx, player.positiony, player.positionz, 10)
    elseif currentDistance > (FOLLOW_RANGE * 2) then 
        walkToPlayerOffset(player.positionx, player.positiony, player.positionz, 5)
    else 
        walkToPlayerOffset(player.positionx, player.positiony, player.positionz, 1.5)
    end

end

function walkToPlayerOffset(x,y,z,speed) 

    local xOff = x + followOffset
    local zOff = z + followOffset

    local playerCoord = "" .. xOff .. "," .. y .. "," .. zOff
    
    orc.consolecommand("walktoloc @self,".. playerCoord .. "," .. walkTimeout .. "," .. speed .. ",false")

end

function reactToSex() 

    --Have various reactions if the player is having sex

    if orc.isbusy then
        return
    end

    local bedActs = {
        "sca1", "sca2"
    }

    local anywhereActs = {
        "ssa1", "sco1", "sc69", "spr1"
    }

    local soloActs = {
        "fap", "floorfap1"
    }

    --If the player is engaged in sex, start sex with other followers
    if player.issexing then 

        --This orc's new objective is nearby.
        orc.getclosest(12)
        local closestFollower = orc.orcobjective

        --Attempt to have sex with another follower
        if isValidSexPartner(closestFollower) then 

            --Set the follower and their intended partner to each other's objectives.
            closestFollower.orcobjective = orc

            --Decide available sex acts.
            local sexActs = nil

            if inSceneWithBed() then 
                sexActs = tableConcat(bedActs, anywhereActs)
            else 
                sexActs = anywhereActs
            end
            
            --Start a sex animation 
            local sexSelect = orc.game.randomint(1, #sexActs+1)

            --If the follower is attempting one of the standing animations, make his partner join him. 
            if sexActs[sexSelect] == "ssa1" or sexActs[sexSelect] == "spr1" then 
                closestFollower.endsex()
                closestFollower.consolecommand(sexActs[sexSelect])
                orc.consolecommand("joinsex")
            else 
                orc.consolecommand(sexActs[sexSelect])
            end

            if orc.issexing then 

                OFDebug("reactToSex", orc.orcname .. " has started sex with " .. closestFollower.orcname)

                sexAttempts = 0
            end
            
        end 

        --If this orcs runs out of attempts to find a sex partner, fap bythemselves.
        if sexAttempts > SEX_ATTEMPTS_MAX then

            OFDebug("reactToSex", orc.orcname .. " has started fapping.")
            
            local sexSelect = orc.game.randomint(1, #soloActs)
            orc.consolecommand(soloActs[sexSelect])

            sexAttempts = 0
        end

        sexAttempts = sexAttempts + 1

    -- Else, if the player is just fapping, then fap with them.
    elseif player.isfapping then 

        if not orc.isfapping then 
            OFDebug("reactToSex", orc.orcname .. " has started fapping.")

            orc.fapstart()
        end
    
    end

end

function isValidSexPartner(closest)

    if closest == nil then 
        OFDebug("isValidSexPartner", orc.orcname .. " attempted to have sex with a nil orc")
        return false 
    end

    if closest.istheplayer then 
        OFDebug("isValidSexPartner", orc.orcname .. " attempted to have sex with the player, but they are sexing someone else")
        return false 
    end

    if closest.isbusy then 
        OFDebug("isValidSexPartner", orc.orcname .. " attempted to have sex with " .. closest.orcname .. " but they are busy")
        return false
    end

    if closest.ifitemflag("OF-FollowState", "FOLLOWING") == false then 
        OFDebug("isValidSexPartner", orc.orcname .. " attempted to have sex with " .. closest.orcname .. " but they aren't a follower")
        return false
    end

    OFDebug("isValidSexPartner", orc.orcname .. " is attempting to have sex with " .. closest.orcname)

    return true
end

function inSceneWithBed() 

    if orc.game.sceneis("BathHouse") or 
       orc.game.sceneis("Inn1") or 
       orc.game.sceneis("Library") then 
        return true
    end

    return false 

end

function cancelActions()

    if player.issexing or player.isfapping then 
        return 
    end

    --If the follower is caught by a genie, don't end sex
    if influencedByGenie() then 
        return
    else 
    
        if orc.isfapping then 
            orc.fapstop()
            OFDebug("cancelActions", orc.orcname .. " has stopped fapping.")
        end
        
        if orc.issexing then 
            orc.endsex()
            OFDebug("cancelActions", orc.orcname .. " has stopped sex.")
        end

    end

end

function influencedByGenie() 

    local drone = orc.findclosest(6)
    if drone == nil then 
        return false
    end

    if drone.corruption >= 3 then 
        return true
    else
        return false 
    end

end

function tableConcat(t1, t2)

    local t3 = {}

    for i=1, #t1 do 
        t3[#t3 + 1] = t1[i]
    end

    for i=1, #t2 do 
        t3[#t3 + 1] = t2[i]
    end

    return t3
end

function OFDebug(functionName, text) 
    -- Print debugging messages out to the console
    orc.debuglog(SCRIPT_NAME .. ", " .. functionName .. "() on " .. orc.orcname .. ":\n\t" .. text)
end