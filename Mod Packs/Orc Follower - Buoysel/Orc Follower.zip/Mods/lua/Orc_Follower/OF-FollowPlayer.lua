--[[
    This orc will follow the player around. They will also
    react to any sex the player is having either by fapping
    by themselves, or by having sex with other followers.
]]

local player = orc.game.orcfromcommandname("@playername")

--Shorthand
local SCRIPT_NAME = "Orc_Follower/OF-FollowPlayer"

-- Follow Range
local FOLLOW_RANGE = 5
local followOffset = math.random() + math.random(-1.5,1.5)
local currentDistance = 0

--If the player is having sex, attempt to have sex with another follower
local SEX_ATTEMPTS_MAX = 3
local sexAttempts = 0
local reactingToSex = false

function start()
    OFDebug("start", "Orc will now listen to player events.")
    orc.luaiterator(SCRIPT_NAME, "checkPlayer", orc.infinity)
end

function follow()
    
    OFDebug("follow", orc.orcname .. " is now following the player")

    orc.setitemflag("OF-IsFollowing", "1")

    --If the orc was previously dismissed, re-start the checkPlayer iterator
    if orc.hasitemflag("OF-Dismissed", "@any") then 
        start()
        orc.consolecommand("removescriptflag OF-Dismissed")
    end 
end

function stopFollowing()
    --Stop the checkPlayer iterator.

    OFDebug("stopFollowing", "checkPlayer iterator cancelled.")

    orc.consolecommand("oluaria " .. SCRIPT_NAME .. ",checkPlayer")
end

function checkPlayer()

    -- If the orc isn't actively following the player, then don't run this function.
    if not orc.ifitemflag("OF-IsFollowing", "1") then 
        return
    end

    --Make sure the player exists in the scene.
    if player == nil then 
        OFDebug("checkPlayer", "Player not found, attempting to find them.")
        player = orc.game.orcfromcommandname("@playername")
        return
    end

    --If the player moves away from the follower, make the follower start walking
    currentDistance = orc.game.distancebetweenorcs(orc,player)
    if  currentDistance > FOLLOW_RANGE or
        currentDistance > (FOLLOW_RANGE + followOffset) then
        
        cancelActions()
        walkToPlayer()

    else 
        --Kill the walking script so the orc doesn't slingshot past the player
        if orc.busywalking then
            orc.walk2clear()
        end 

        if player.issexing or player.isfapping then 
            reactToSex()
        else
            cancelActions()
        end
    end

    if player.isairborne and not orc.isairborne then 
        
        --[[Orcs can get stuck if they're jumping during the quick grow animation, and
          unfreezenode doens't seem to fix it. So just stop jumping all together
          if they're about to change.
        ]]
        if orc.corruption < 3 then
            orc.fapstop() 
            orc.jump(1)
        end
    end

end

function walkToPlayer() 

    --Attempt to allow the orc to walk again if they had sex at some point
    if not orc.busywalking then 
        orc.consolecommand("unfreezenode")
    end

    if currentDistance > 50 then 
        orc.consolecommand("tp2orcquiet @playername")
    elseif currentDistance > (FOLLOW_RANGE * 5) then 
        walkToPlayerOffset(player.positionx, player.positiony, player.positionz, 10)
    elseif currentDistance > (FOLLOW_RANGE * 2) then 
        walkToPlayerOffset(player.positionx, player.positiony, player.positionz, 5)
    else 
        walkToPlayerOffset(player.positionx, player.positiony, player.positionz, 1.5)
    end

end

function walkToPlayerOffset(x,y,z,speed) 

    local xOff = x + followOffset
    local zOff = z + followOffset

    local playerCoord = "" .. xOff .. "," .. y .. "," .. zOff
    
    orc.consolecommand("walktoloc @self,".. playerCoord .. ",Infinity," .. speed .. ",false")

end

function reactToSex() 

    --Have various reactions if the player is having sex

    if orc.isbusy then
        return
    end

    --If the player is engaged in sex, start sex with other followers
    if player.issexing then 

        --This orc's new objective is nearby.
        orc.getclosest(12)
        local closestFollower = orc.orcobjective

        --Attempt to have sex with another follower
        if isValidSexPartner(closestFollower) then 
            
            --Start a sex animation 
            
            if orc.game.sceneis("BathHouse") or 
               orc.game.sceneis("Inn1") then 

                local sexSelect = orc.game.randomint(0,4)
                if sexSelect == 0 then 
                    orc.consolecommand("sco1")
                elseif sexSelect == 1 then 
                    orc.consolecommand("sc69")
                elseif sexSelect == 2 then 
                    orc.consolecommand("sca1")
                elseif sexSelect == 3 then 
                    orc.consolecommand("sca2")
                end

            else

                local sexSelect = orc.game.randomint(0,2)
                if sexSelect == 0 then 
                    orc.consolecommand("sco1")
                elseif sexSelect == 1 then 
                    orc.consolecommand("sc69")
                end
        
            end

            if orc.issexing then 

                OFDebug("reactToSex", orc.orcname .. " has started sex with " .. closestFollower.orcname)

                reactingToSex = true
                sexAttempts = 0
            end
            
        end 

        --If this orcs runs out of attempts to find a sex partner, fap bythemselves.
        if sexAttempts > SEX_ATTEMPTS_MAX then

            OFDebug("reactToSex", orc.orcname .. " has started fapping.")
            
            local sexSelect = orc.game.randomint(0,2)

            if sexSelect == 0 then 
                orc.fapstart()
            elseif sexSelect == 1 then
                orc.consolecommand("floorfap1")
            end

            reactingToSex = true
            sexAttempts = 0
        end

        sexAttempts = sexAttempts + 1

    -- Else, if the player is just fapping, then fap with them.
    elseif player.isfapping then 

        if not orc.isfapping then 
            OFDebug("reactToSex", orc.orcname .. " has started fapping.")

            orc.fapstart()
            reactingToSex = true
        end
    
    end

end

function isValidSexPartner(closest)

    if closest == nil then 
        OFDebug("isValidSexPartner", orc.orcname .. " attempted to have sex with a nil orc")
        return false 
    end

    if closest.istheplayer then 
        OFDebug("isValidSexPartner", orc.orcname .. " attempted to have sex with the player, but they are sexing someone else")
        return false 
    end

    if closest.isbusy then 
        OFDebug("isValidSexPartner", orc.orcname .. " attempted to have sex with " .. closest.orcname .. " but they are busy")
        return false
    end

    if closest.ifitemflag("OF-IsFollowing", "1") == false then 
        OFDebug("isValidSexPartner", orc.orcname .. " attempted to have sex with " .. closest.orcname .. " but they aren't a follower")
        return false
    end

    OFDebug("isValidSexPartner", orc.orcname .. " is attempting to have sex with " .. closest.orcname)

    return true
end

function cancelActions()
    
    if not reactingToSex then
        return
    else 
        reactingToSex = false
    end

    if orc.isfapping then 
        orc.fapstop()
    end
    
    if orc.issexing then 
        orc.endsex()
    end

    OFDebug("cancelActions", "Actions cancelled.")

end

function OFDebug(functionName, text) 
    -- Print debugging messages out to the console
    orc.debuglog(SCRIPT_NAME .. ", " .. functionName .. "() on " .. orc.orcname .. ":\n\t" .. text)
end