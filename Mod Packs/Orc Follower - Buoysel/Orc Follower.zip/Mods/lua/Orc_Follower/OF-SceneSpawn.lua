--[[
    Manages the scene the follower should spawn in.
]]

local player = orc.game.orcfromcommandname("@playername")

-- Shorthand
local SCRIPT_NAME = "Orc_Follower/OF-SceneSpawn"
local SPAWN_FLAG = "OF-" .. orc.orcname .. "-OrgSpawn"

-- Follower should reload scene if they were instructed to wait
local askedToWait = false

function onscenechange()

    -- When the player travels to a new scene, follow them.

    if not orc.ifitemflag("OF-IsFollowing", "1") then 
        return
    end

    -- For the Bonfire or Limbo scenes, do not let the follower travel with you.
    if inInvalidScene() then 

        OFDebug("onscenechange", "Staying in the Outback. Player is heading to a forbidden scene.")
        setChrScene("Outback1",999,999,999)
    else
        OFDebug("onscenechange", "Warping to " .. player.game.nextscene .. "...")
        setChrScene(player.game.nextscene,999,999,999)
    end

end

function onscenechanged()

    -- Do a roll call when spawning to the new scene.
    OFDebug("onscenechanged", orc.orcname .. " has successfully made it to " .. player.game.nextscene)

end

function waitHere()

    --Make the follower remain in the scene they're standing in when they're no longer following the player.

    if inInvalidScene() then 

        OFDebug("waitHere", "Attempted to leave " .. orc.orcname .. " in an invalid location")
        player.consolecommand("infodialogue Command ignored. It would be a REALLY bad idea to leave him here...")
        return

    end

    OFDebug("waitHere", orc.orcname .. " is now waiting at " .. orc.game.nextscene .. 
                                                    "\n\t\tX: " .. orc.positionx .. 
                                                    "\n\t\tY: " .. orc.positiony .. 
                                                    "\n\t\tZ: " .. orc.positionz)

    setChrScene(orc.game.nextscene, orc.positionx, orc.positiony, orc.positionz)

    orc.setitemflag("OF-IsFollowing", "0")
    orc.walk2clear()

    askedToWait = true

end

function dismiss()

    -- Makes the follower return to their old spawn point.

    -- Dismissing from certain scenes will prevent the orc from returning to their spawn point.
    if inInvalidScene() then 
        OFDebug("dismiss", "Attempted to dismiss " .. orc.orcname .. " from an invalid location.")
        orc.consolecommand("infodialogue They can't be dismissed from here. Try going somewhere else first.")
        return
    end

    local spawnTable = splitString(orc.itemflagstring(SPAWN_FLAG))

    -- The followers original coordinates are only created when they follow the player
    -- around for the first time. In case they are nil, return from this function.
    if spawnTable == nil then 
        OFDebug("dismiss", orc.orcname .. "'s spawn data has gone missing. Dismiss cancelled.")
        orc.consolecommand("infodialogue This orc's spawn data is missing. Unable to dismiss them.")
        return
    end

    local spawnScene = spawnTable[1]
    local spawnX = tonumber(spawnTable[2])
    local spawnY = tonumber(spawnTable[3])
    local spawnZ = tonumber(spawnTable[4])     

    setChrScene(spawnScene, spawnX, spawnY, spawnZ)

    orc.setitemflag("OF-IsFollowing", "0")
    orc.setitemflag("OF-Dismissed", "1")
    
    orc.consolecommand("removescriptflag " .. SPAWN_FLAG)
    orc.walk2clear()

    saluteAndVanish(spawnScene, spawnX, spawnY, spawnZ)

    OFDebug("dismiss", orc.orcname .. " has been dismissed.")

end

function saluteAndVanish(spawnScene, spawnX, spawnY, spawnZ)

    -- Make the orc wave or salute to the player before vanishing in a puff of smoke.
    local salutePick = orc.game.randomint(0,3)

    orc.consolecommand("invokedelay 0.5")

    if salutePick == 0 then 
        orc.consolecommand("invoke batch target @self;buff NoLookAtBody,2.5;forceanim Armature|OrcSalute;targetclear")
    elseif salutePick == 1 then 
        orc.consolecommand("invoke batch target @self;buff NoLookAtBody,2.5;forceanim Armature|OrcSalute2;targetclear")
    elseif salutePick == 2 then 
        orc.consolecommand("invoke batch target @self;buff NoLookAtBody,2.5;forceanim Armature|Wave;targetclear")
    end

    --Temporarily copy the control to the player and make them reload the scene
    if not player.ifitemflag("OF-Dismissing-Orc", "1") then 

        player.setitemflag("OF-Dismissing-Orc", "1")

        orc.luacopyover(orc, player, "Orc_Follower/OF-PlayerControls")
        player.consolecommand("oluacf Orc_Follower/OF-PlayerControls,dismissAndWait")
    end

end

function setChrScene(scene, xCoord, yCoord, zCoord)

    local spawnCoords = scene .. "," ..  
                        xCoord .. "," ..     
                        yCoord .. "," ..     
                        zCoord               

    OFDebug("setChrScene", orc.orcname .. " will spawn at " .. spawnCoords)

    orc.consolecommand("setchrscene " .. spawnCoords)

end

function saveOriginalSpawn() 

    -- Save this orc's original spawn in the players's inventory.
    if orc.hasitemflag(SPAWN_FLAG, "@any") then 
        return
    end

    local spawnCoords = orc.game.nextscene .. ";" .. 
                        orc.positionx .. ";" ..
                        orc.positiony .. ";" ..
                        orc.positionz

    OFDebug("saveOriginalSpawn", orc.orcname .. "'s original spawn has been saved: " .. spawnCoords)

    orc.setitemflag(SPAWN_FLAG, spawnCoords)
    
end

function splitString(inputstr)

    --Splits the original spawn data flag 

    OFDebug("splitString", "Attempting to retrieve " .. orc.orcname .. "'s spawn data.")

    if inputstr == nil or inputstr == "" then 
        OFDebug("splitString", orc.orcname .. "'s spawn data is not found. Cancelling.")
        return nil 
    end
    
    local sep = ";"
    local t = {}

    for str in string.gmatch(inputstr, "([^" .. sep .. "]+)") do
        table.insert(t,str)
    end

    return t
end

function inInvalidScene() 

    --Don't let the player leave the orc in the Bonfire or Test scenes

    if string.find(player.game.nextscene, "Bonfire") or
        string.find(player.game.nextscene, "Limbo") or 
        string.find(player.game.nextscene, "Empty") then 

            return true

    end

    return false

end

function onsave()

    if orc.istheplayer or player.isbusy then 
        return 
    end

    if orc.ifitemflag("OF-IsFollowing", "1") then
        OFDebug("onsave", "Game was saved. Marking follower to spawn at Outback")
        setChrScene("Outback1", 999, 999, 999)
    end

    --Temporarily copy the control to the player and make them save.
    if (orc.ifitemflag("OF-IsFollowing", "1") or askedToWait) and 
       not player.ifitemflag("OF-Saving", "1") then 

        player.setitemflag("OF-Saving", "1")

        orc.luacopyover(orc, player, "Orc_Follower/OF-PlayerControls")
        player.consolecommand("oluacf Orc_Follower/OF-PlayerControls,waitAndSave")
    end

    askedToWait = false

end

function OFDebug(functionName, text) 
    -- Print debugging messages out to the console
    orc.debuglog(SCRIPT_NAME .. ", " .. functionName .. "() on " .. orc.orcname .. ":\n\t" .. text)
end