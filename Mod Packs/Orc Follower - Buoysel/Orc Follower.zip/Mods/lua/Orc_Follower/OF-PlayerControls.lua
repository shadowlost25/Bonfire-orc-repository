--[[
    Player-specific controls to handle saving and scene reloads.
]]

-- Shorthand
local SCRIPT_NAME = "Orc_Follower/OF-PlayerControls"

-- Store the players previous position
local posX, posY, posZ = 0,0,0

-- Generally do not allow this script to exist on the player when not necessary.
local canDeleteScript = true

-- Set a timer for when the player uses the profile menu to restore their shape.
local deleteTimer = 0
local DELETE_MAX = 20

function start()

    if filters() then return end

    OFDebug("start", "Player Controls copied to the player")

    OFDebug("start", "Player coordinates captured")
    posX = orc.positionx
    posY = orc.positiony
    posZ = orc.positionz

    OFDebug("start", "Time limit initiated")
    orc.luaiterator(SCRIPT_NAME, "selfDestruct", orc.infinity)

end

function onscenechanged()

    if filters() then return end

    if canDeleteScript then 
        deleteControls()
    end

end

function waitAndSave()

    --Save and Replicate the "Laydown and Skip Time" feature

    if filters() or orc.isbusy then 
        return 
    end

    canDeleteScript = false

    OFDebug("waitAndSave", "Game was saved. Player is reloading scene.")

    orc.consolecommand("invokedelay 1")
    orc.consolecommand("casc invoke batch target @playername;fadecolor 0,0,0,255,0,0,0,0,1;oluacf " .. SCRIPT_NAME .. ",forceLoc;removescriptflag OF-Saving;oluarem " .. SCRIPT_NAME .. ";targetclear")
    orc.consolecommand("invoke batch target @playername;fadecolor 0,0,0,0,0,0,0,255,1;sound Sound/teleport2,1;save;invokedelay 1.5;invoke relquietsave;targetclear")

end

function dismissAndWait()

    --Replicate the "Laydown and Skip Time" feature w/o saving

    if filters() then return end

    canDeleteScript = false

    OFDebug("dismissAndWait", "Follower dismissed. Player is reloading the scene")

    orc.consolecommand("invokedelay 1")
    orc.consolecommand("casc invoke batch target @playername;fadecolor 0,0,0,255,0,0,0,0,1;oluacf " .. SCRIPT_NAME .. ",forceLoc;removescriptflag OF-Dismissing-Orc;oluarem " .. SCRIPT_NAME .. ";targetclear")
    
    orc.consolecommand("invokedelay 3")
    orc.consolecommand("invoke batch target @playername;fadecolor 0,0,0,0,0,0,0,255,1;sound Sound/teleport2,1;invokedelay 1.5;invoke relquietsave;targetclear")
end

function forceLoc()
    -- Teleport the player to where they saved previously.

    orc.tp2pos(posX, posY, posZ)
    OFDebug("forceLoc", "Warping player back to X:" .. posX .. ", Y:" .. posY .. ", Z:" .. posZ)
end

function selfDestruct()

    --[[
        Script will delete itself after 20 seconds. This is here for cases where
        the player quickly opens and close the profiles window to restore their
        form, as doing so causes the script and data flag to return to the player's
        inventory and prevents them from saving...
    ]]

    if deleteTimer < DELETE_MAX then 
        deleteTimer = deleteTimer + orc.game.deltatime
        return 
    end

    deleteControls()

end

function deleteControls()
    orc.consolecommand("removescriptflag OF-Saving")
    orc.consolecommand("removescriptflag OF-Dismissing-Orc")
    orc.consolecommand("oluarem " .. SCRIPT_NAME)
end

function filters()
    return not orc.istheplayer
end

-- Print debugging messages out to the console
function OFDebug(functionName, text) 
    orc.debuglog(SCRIPT_NAME .. ", " .. functionName .. "() on " .. orc.orcname .. ":\n\t" .. text)
end
