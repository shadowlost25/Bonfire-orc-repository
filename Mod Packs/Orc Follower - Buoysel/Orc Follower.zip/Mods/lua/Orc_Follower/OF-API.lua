--[[
    The API Implementation for the followers' commands.
]]

local player = orc.game.orcfromcommandname("@playername")

-- Shorthand
local SCRIPT_NAME = "Orc_Follower/OF-API"
local BS_SCRIPT = "Orc_Follower/OF-BedSpawner"
local SS_SCRIPT = "Orc_Follower/OF-SceneSpawn"
local FP_SCRIPT = "Orc_Follower/OF-FollowPlayer"

-- Iterator flags
local tryingToForeplay = false
local tryingToSex = false

function start()

    orc.luaiterator(SCRIPT_NAME, "onGenieAgent", orc.infinity)

end

function follow()

    OFDebug("follow", "Commanding " .. orc.orcname .. " to follow")

    orc.consolecommand("forceanim Armature|Idle1")
    orc.consolecommand("oluacf " .. SS_SCRIPT .. ",saveOriginalSpawn")
    orc.consolecommand("oluacf " .. FP_SCRIPT .. ",follow")

end

function waitHere()

    OFDebug("waitHere", "Commanding " .. orc.orcname .. " to wait")
    orc.consolecommand("oluacf " .. SS_SCRIPT .. ",waitHere")

end

function dismiss() 

    -- Send this orc back to their original spawn point 
    -- and stop the follow iterator.

    OFDebug("dismiss", "Dismissing " .. orc.orcname.. ".\n\tFollower iterator paused.\n\tStopping any dancing.")

    orc.consolecommand("forceanim Armature|Idle1")
    orc.consolecommand("oluaria ".. SCRIPT_NAME ..",stopDancing")

    orc.consolecommand("oluacf " .. SS_SCRIPT .. ",dismiss")
    
    if orc.ifitemflag("OF-Dismissed", "1") then 
        orc.consolecommand("oluacf " .. FP_SCRIPT .. ",stopFollowing")
    end
end

function sca1Top()
    -- Doggy Style: Topping
    startSex(player, orc, "sca1")
end

function sca1Bottom()
    -- Doggy Style: Bottoming
    startSex(orc, player, "sca1")
end

function sca2Top()
    -- Missionary: Topping
    startSex(player, orc, "sca2")
end

function sca2Bottom()
    -- Missionary: Bottoming
    startSex(orc, player, "sca2")
end

function sco1Give() 
    --Give the orc a blowjob
    startSex(orc, player, "sco1")
end

function sco1Receive()
    --Receive a blowjob from the Orc
    startSex(player, orc, "sco1")
end

function sc69Start()
    --Give the orc a blowjob
    startSex(orc, player, "sc69")
end

function startForeplay()

    --Enable the follower to foreplay with the player. 

    if tryingToForeplay then 

        OFDebug("startForeplay", "Attempting foreplay.")
        player.tp2pos(orc.positionx+0.5, orc.positiony, orc.positionz+0.5)
        orc.consolecommand("oldforeplay")

        if orc.isbusy then

            OFDebug("startForeplay", "Foreplay started. Stoping iterator.")
            orc.consolecommand("oluaria ".. SCRIPT_NAME ..",startForeplay")
            tryingToForeplay = false

        end
        
    else

        OFDebug("startForeplay", "Foreplay iterator started.")
        orc.luaiterator(SCRIPT_NAME, "startForeplay", orc.infinity)
        tryingToForeplay = true

    end
    
end

function openInventory()
    OFDebug("openInventory", "Opening inventory")
    orc.consolecommand("forceinventory")
end

function dance() 
    
    --The follower will randomly pick a dance.

    if orc.isbusy then 
        return
    end

    OFDebug("dance", "Selecting a dance...")

    local dance = orc.game.randomint(0,4)

    --Random delay so followers don't dance at the same time in an AOE setting...
    local randomDelay = math.random() + math.random(0,3)
    orc.consolecommand("batch target @self;invokedelay " .. randomDelay)

    if dance == 0 then 
        OFDebug("dance", orc.orcname .. " started Dance1")
        orc.consolecommand("invoke batch target @self;forceanim Dance1;targetclear")
    elseif dance == 1 then 
        OFDebug("dance", orc.orcname .. " started Dance2")
        orc.consolecommand("invoke batch target @self;forceanim Dance2;targetclear")
    elseif dance == 2 then 
        OFDebug("dance", orc.orcname .. " started TribalDance1")
        orc.consolecommand("invoke batch target @self;forceanim Gesture Tribal Dance 1;targetclear")
    elseif dance == 3 then 
        OFDebug("dance", orc.orcname .. " started Dance4")
        orc.consolecommand("invoke batch target @self;forceanim Dance4;targetclear")
    end

    orc.luaiterator(SCRIPT_NAME, "stopDancing", orc.infinity)

end

function stopDancing()

    --Forces orc to go back into their idle animation.
    if orc.isbusy then 
        OFDebug("dance", orc.orcname .. " stopped Dancing")
        orc.consolecommand("forceanim Armature|Idle1")
        orc.consolecommand("oluaria ".. SCRIPT_NAME ..",stopDancing")
    end
end

function spawnBed()
    
    --The orc will spawn a bed under their feet.
    --NOTE: Any of the sex commands will do this automatically.

    orc.consolecommand("oluacf " .. BS_SCRIPT .. ",spawnBed")

end


function removeBed()

    --The orc will delete their spawned bed.
    --NOTE: Any of the sex commands will do this automatically.


    --Use the below commands to prevent the game from softlocking when manually removing a bed
    --during dialogue.
    orc.consolecommand("batch target @playername;orccallback sex2diag;animatorreset;")
    orc.consolecommand("invokedelay 0.1")
    orc.consolecommand("invoke batch target @self;oluacf " .. BS_SCRIPT .. ",removeBed;targetclear")

end

function startSex(top, bottom, sexpos) 

    --Start a sex act

    if tryingToSex then 

        OFDebug("startSex", "Attempting sex with player... Top: " .. top.orcname .. ", Bottom: " .. bottom.orcname .. ", Sex act: " .. sexpos)

        if orc.istalking or player.istalking then 
            return
        end

        --Sometimes the player might accidentally fap when the dialogue closes
        top.fapstop()
        bottom.fapstop()

        --Warp the follower to the player
        orc.tp2pos(player.positionx, player.positiony, player.positionz)

        --Spawn a bed for the anal animations
        if sexpos == "sca1" or sexpos == "sca2" then 
            orc.consolecommand("oluacf " .. BS_SCRIPT .. ",spawnBed")
        end

        --Pick a sex act
        top.orcobjset(bottom.orcname)
        top.consolecommand(sexpos)
    end

    -- If the Orc is sexing, stop iterating the sex function
    if orc.issexing then 

        OFDebug("startSex", top.orcname .. " has started " .. sexpos .. " with " .. bottom.orcname .. ". Stopping iterators.")

        tryingToSex = false

        --Remove the bed if this is an anal animation
        if (sexpos == "sca1" or sexpos == "sca2") then 

            orc.luaiterator(BS_SCRIPT, "despawnBedPostSex", orc.infinity)

            if player == top then 
                orc.consolecommand("oluaria ".. SCRIPT_NAME .."," .. sexpos .. "Top")
            else 
                orc.consolecommand("oluaria ".. SCRIPT_NAME .."," .. sexpos .. "Bottom")
            end

        elseif sexpos == "sco1" then  

            if player == top then 
                orc.consolecommand("oluaria ".. SCRIPT_NAME .."," .. sexpos .. "Receive")
            else 
                orc.consolecommand("oluaria ".. SCRIPT_NAME .."," .. sexpos .. "Give")
            end

        elseif sexpos == "sc69" then 

            orc.consolecommand("oluaria ".. SCRIPT_NAME ..",sc69Start")

        end


    -- Else, iterate the sex function
    elseif not orc.issexing and not tryingToSex then

        OFDebug("startSex", "Starting sex iterator.")

        tryingToSex = true

        if (sexpos == "sca1" or sexpos == "sca2") then 

            if player == top then 
                orc.luaiterator(SCRIPT_NAME, sexpos .. "Top", orc.infinity)
            else 
                orc.luaiterator(SCRIPT_NAME, sexpos .. "Bottom", orc.infinity)
            end

        elseif sexpos == "sco1" then  

            if player == top then 
                orc.luaiterator(SCRIPT_NAME, sexpos .. "Receive", orc.infinity)
            else 
                orc.luaiterator(SCRIPT_NAME, sexpos .. "Give", orc.infinity)
            end

        elseif sexpos == "sc69" then 

            orc.luaiterator(SCRIPT_NAME, "sc69Start", orc.infinity)

        end

    end

end

function onGenieAgent()

    -- Disable OF when the follower becomes a drone so they can't warp to the player directly.

    --If the orc is geniefied, and the genieagent script is present, then put the follower on standby
    if orc.hasluascript("genieagent") and orc.corruption >= 3 then 
        
        if orc.ifitemflag("OF-IsFollowing", "1") then 
            
            waitHere()

            --And in case someone has brought the follower to a forbiddenscene, 
            --place them on standby anyway so they don't get spammed with messages.
            orc.setitemflag("OF-IsFollowing", "0")

            OFDebug("onGenieAgent", orc.orcname .. " has become a Drone! He will no longer follow orders.")

        end
        
    end
    
end

function OFDebug(functionName, text) 
    -- Print debugging messages out to the console
    orc.debuglog(SCRIPT_NAME .. ", " .. functionName .. "() on " .. orc.orcname .. ":\n\t" .. text)
end