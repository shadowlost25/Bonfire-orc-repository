--[[
    The API Implementation for the followers' commands.
]]

local player = orc.game.orcfromcommandname("@playername")

-- Shorthand
local SCRIPT_NAME = "Orc_Follower/OF-API"
local BS_SCRIPT = "Orc_Follower/OF-BedSpawner"
local SS_SCRIPT = "Orc_Follower/OF-SceneSpawn"
local FP_SCRIPT = "Orc_Follower/OF-FollowPlayer"
local RX_SCRIPT = "Orc_Follower/OF-Relax"

function follow()

    OFDebug("follow", "Commanding " .. orc.orcname .. " to follow")

    orc.luacallfunction(RX_SCRIPT,"stopRelaxing")

    orc.luacallfunction(SS_SCRIPT,"saveOriginalSpawn")

    orc.luacallfunction(FP_SCRIPT,"startFollowing")
    
end

function waitHere()

    OFDebug("waitHere", "Commanding " .. orc.orcname .. " to wait")
    
    orc.luacallfunction(FP_SCRIPT,"stopFollowing")
    orc.luacallfunction(RX_SCRIPT,"stopRelaxing")

    orc.luacallfunction(SS_SCRIPT, "waitHere")

end

function relax() 

    OFDebug("relax", "Commanding " .. orc.orcname .. " to hang around")

    orc.luacallfunction(FP_SCRIPT,"stopFollowing")

    orc.luacallfunction(RX_SCRIPT,"startRelaxing")

end

function moveToLocation()

    OFDebug("moveToLocation", "Commanding " .. orc.orcname .. " to move to a new spot")

    waitHere()

    if orc.ifitemflag("OF-FollowState", "WAITING") then 

        if not orc.game.ifsceneflag("OF-HasMovedFollower", "1") then 
            player.consolecommand("infodialogue \"Where to?\" \n\n(Move the cursor to a spot and then right-click to direct the follower)")
            orc.game.setsceneflag("OF-HasMovedFollower", "1")                
        end

        orc.say("Where do you want me?")

        orc.consolecommand("walkcmd")

    end

end

function dismiss() 

    -- Send this orc back to their original spawn point 
    -- and stop the follow iterator.

    OFDebug("dismiss", "Dismissing " .. orc.orcname.. ".\n\tFollower and Relax iterator paused.\n\tStopping any dancing.")

    orc.luacallfunction(FP_SCRIPT,"stopFollowing")
    orc.luacallfunction(RX_SCRIPT,"stopRelaxing")


    orc.consolecommand("forceanim Armature|Idle1")
    orc.consolecommand("oluaria ".. SCRIPT_NAME ..",stopDancing")

    orc.consolecommand("oluacf " .. SS_SCRIPT .. ",dismiss")
    
end

function openInventory()
    OFDebug("openInventory", "Opening inventory")
    orc.consolecommand("forceinventory")
end

function dance() 
    
    --The follower will randomly pick a dance.

    if orc.isbusy then 
        return
    end

    OFDebug("dance", "Selecting a dance...")

    local dances = {
        "Dance1", "Dance2", "Gesture Tribal Dance 1",
        "Dance4", "Dance5", "Dance5b", "dance6", "dance7"
    }

    local danceIndex = orc.game.randomint(1, #dances + 1)
    
    --Random delay so followers don't dance at the same time in an AOE setting...
    local randomDelay = math.random() + math.random(0,3)
    orc.consolecommand("batch target @self;invokedelay " .. randomDelay)

    OFDebug("dance", orc.orcname .. " started " .. dances[danceIndex])
    orc.consolecommand("invoke batch target @self;forceanim " .. dances[danceIndex] .. ";targetclear")

    orc.luaiterator(SCRIPT_NAME, "stopDancing", orc.infinity)

end

function stopDancing()

    --Forces orc to go back into their idle animation for cases where they're in dialogue
    if orc.isbusy or orc.istalking or orc.busywalking then 
        OFDebug("dance", orc.orcname .. " stopped Dancing")
        orc.consolecommand("forceanim Armature|Idle1")
        orc.consolecommand("oluaria ".. SCRIPT_NAME ..",stopDancing")
    end
end

function spawnBed()
    
    --The orc will spawn a bed under their feet.
    --NOTE: Any of the sex commands will do this automatically.

    orc.consolecommand("oluacf " .. BS_SCRIPT .. ",spawnBed")

end


function removeBed()

    --The orc will delete their spawned bed.
    --NOTE: Any of the sex commands will do this automatically.

    --Use the below commands to prevent the game from softlocking when manually removing a bed
    --during dialogue.
    orc.consolecommand("batch target @playername;orccallback sex2diag;animatorreset;")
    orc.consolecommand("invokedelay 0.1")
    orc.consolecommand("invoke batch target @self;oluacf " .. BS_SCRIPT .. ",removeBed;targetclear")

end

function sca1Top()
    -- Doggy Style: Topping
    setSexAct(player, orc, "sca1")
end

function sca1Bottom()
    -- Doggy Style: Bottoming
    setSexAct(orc, player, "sca1")
end

function ssa1Top()
    -- Standing Doggy Style: Topping
    setSexAct(player, orc, "ssa1")
end

function ssa1Bottom()
    -- Standing Doggy Style: Bottoming
    setSexAct(orc, player, "ssa1")
end

function sca2Top()
    -- Missionary: Topping
    setSexAct(player, orc, "sca2")
end

function sca2Bottom()
    -- Missionary: Bottoming
    setSexAct(orc, player, "sca2")
end

function spr1Top() 
    -- Cowgirl: Topping 
    setSexAct(player, orc, "spr1")
end 

function spr1Bottom() 
    -- Cowgirl: Topping 
    setSexAct(orc, player, "spr1")
end

function sco1Give() 
    --Give the orc a blowjob
    setSexAct(orc, player, "sco1")
end

function sco1Receive()
    --Receive a blowjob from the Orc
    setSexAct(player, orc, "sco1")
end

function sc69Start()
    --Give the orc a blowjob
    setSexAct(player, orc, "sc69")
end

function setSexAct(top, bottom, sexpos) 

    -- Create data flags in the follower's inventory for the sex top, bottom, and act 

    orc.setitemflag("OF-SexTop", top.orcname)
    orc.setitemflag("OF-SexBtm", bottom.orcname)
    orc.setitemflag("OF-SexAct", sexpos)
    orc.setitemflag("OF-TryingToSex", "true")

    -- Stop the follow and relax iterators so the followers tops cancelling sex. 
    waitHere()

    -- Begin the startSex iterator
    orc.luaiterator(SCRIPT_NAME, "startSex", orc.infinity)
end

function startSex()

    local top = orc.game.orcfromcommandname(orc.itemflagstring("OF-SexTop"))
    local bottom = orc.game.orcfromcommandname(orc.itemflagstring("OF-SexBtm"))
    local sexpos = orc.itemflagstring("OF-SexAct")

    local standAlonePoses = {
        ssa1 = "ssa1", spr1 = "spr1"
    }

    local bedPoses = {
        sca1 = "sca1", sca2 = "sca2"
    }

    -- Start sex with the follower
    if orc.hasitemflag("OF-TryingToSex", "true") then

        OFDebug("startSex", "Attempting sex with player... Top: " .. top.orcname .. ", Bottom: " .. bottom.orcname .. ", Sex act: " .. sexpos)

        if orc.istalking or player.istalking then 
            return 
        end

        --Sometimes the player might accidentally fap when the dialogue closes
        top.fapstop()
        bottom.fapstop()

        --Warp the follower to the player
        orc.tp2pos(player.positionx, player.positiony, player.positionz)

        --Spawn a bed for the anal animations
        if bedPoses[sexpos] ~= nil then 
            orc.consolecommand("oluacf " .. BS_SCRIPT .. ",spawnBed")
        end
        
        --Set objective and start sex act.
        
        --If the sex act is a standalone, reverse the order
        if standAlonePoses[sexpos] ~= nil then 
            bottom.consolecommand(sexpos)
            top.consolecommand("joinsex")

        else 
            top.orcobjset(bottom.orcname)
            top.consolecommand(sexpos)
        end

    end
    
    -- If the Orc is sexing, stop iterating the sex fuction
    if orc.orcobjective.issexing and orc.issexing then 
        
        OFDebug("startSex", top.orcname .. " has started " .. sexpos .. " with " .. bottom.orcname .. ". Stopping iterators.")

        orc.remitemflag("OF-SexTop")
        orc.remitemflag("OF-SexBtm")
        orc.remitemflag("OF-SexAct")
        orc.remitemflag("OF-TryingToSex")

        --Remove the bed if the animation requires it.
        if bedPoses[sexpos] ~= nil then 
            orc.luaiterator(BS_SCRIPT, "despawnBedPostSex", orc.infinity)
        end

        orc.remiterators(SCRIPT_NAME, "startSex")
    end
    
end

function oncursed()

    -- The follower has become too distracted by the curse to obey orders.
    decideCursedBehavior()

end 

function ongeniefied()

    -- The follower has become too distracted by the curse to obey orders.
    orc.say("Ahurr... ahurr hurr hurr... fuck...")
    pauseOF()
    decideCursedBehavior()

end

function pauseOF()

    if orc.ifitemflag("OF-FollowState", "FOLLOWING") or 
       orc.ifitemflag("OF-FollowState", "RELAXING") then 
            
        waitHere()

        --And in case someone has brought the follower to a forbiddenscene, 
        --place them on standby anyway so they don't get spammed with messages.
        orc.setitemflag("OF-FollowState", "WAITING")

        OFDebug("onGenieAgent", orc.orcname .. " has become a Drone! He will no longer follow orders.")

    end
end

--Decides whether followers should use the genie agent or not.
function decideCursedBehavior()

    orc.consolecommand("invokedelay 0.5")
    if orc.corruption >= 0 and orc.corruption < 3 then 
        orc.consolecommand("gm_gagentoff")
        orc.fapstop()
        orc.endsex()

        --For Lore NPCs, re-apply the LoreNPC dialogue. For other NPCs, restore modspeech.
        if orc.iscorechr and orc.modspeechname ~= "Diag-LoreNPC" then
            orc.consolecommand("invoke batch target @self;modspeech Orc_Follower/Diag-LoreNPC;targetclear")
            OFDebug("decideCursedBehavior", "Disabling genieagent, swapping out DroneSpeech and reapplying Diag-LoreNPC modspeech.")

        elseif not orc.iscorechr and orc.modspeechname ~= nil then
            orc.consolecommand("invoke batch target @self;modspeechrestore;targetclear")
            OFDebug("decideCursedBehavior", "Disabling genieagent and restoring default speech.")

        end

    elseif orc.corruption >= 3 and orc.modspeechname ~= "DroneSpeech" then 
        orc.luacallfunction("OrcFollower", "disableClickchoice")
        orc.consolecommand("gm_gagenton")
        orc.consolecommand("invoke batch target @self;modspeech DroneSpeech;targetclear")
        OFDebug("decideCursedBehavior", "Reactivating Drone speech and Genie Agent.")

    end

end

orc.consolecommand("invokedelay 0.5")
orc.consolecommand("invoke batch target @self;oluacf " .. SCRIPT_NAME .. ",decideCursedBehavior")

function OFDebug(functionName, text) 
    -- Print debugging messages out to the console
    orc.debuglog(SCRIPT_NAME .. ", " .. functionName .. "() on " .. orc.orcname .. ":\n\t" .. text)
end