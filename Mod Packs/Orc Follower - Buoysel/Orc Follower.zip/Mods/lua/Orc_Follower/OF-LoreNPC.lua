--[[
    Grants Lore NPCs Follower Dialogue
]]

--Shorthand
local SCRIPT_NAME = "Orc_Follower/OF-LoreNPC"

--NPC Speech for corruption
local currentSpeech = nil

--Cooldown for when Bolt complains
local YELL_WAIT = 2
local yellTimer = 0
local boltYelling = false

function start()

    OFDebug("start", "Recruiting Lore NPC...")

    recruitLoreNPC()

    --Add some Bolt-specific filters
    if orc.orcname == "Bolt" then 
        orc.setitemflag("OF-Bolt-Vanished", "0")
        orc.luaiterator(SCRIPT_NAME, "filterBolt", orc.infinity)
    end

    --Prevent the curse from replacing dialogue
    orc.luaiterator(SCRIPT_NAME, "onCurse", orc.infinity)

end

function recruitLoreNPC()

    OFDebug("recruitLoreNPC", "Replacing speech with follower dialogue")

    -- Injects the Lore NPC with Follower dialogue and replaces their regular speech.
    orc.consolecommand("modspeech Orc_Follower/Diag-LoreNPC")
end

function dismissLoreNPC()

    OFDebug("dismissLoreNPC", "Restoring vanilla dialogue")

    -- Restore the Lore NPC's original speech
    orc.consolecommand("modspeechrestore")

    -- Remove the special Lore NPC flags
    orc.consolecommand("removescriptflag OF-LoreNPCIs")
    orc.consolecommand("removescriptflag OF-Bolt-Vanished")
end

function filterBolt()

    --Do not allow Bolt to engage in any sex acts unless he is corrupted.
    if orc.corruption > 0 then 
        return 
    end

    if orc.issexing then 
        orc.endsex()
        orc.consolecommand("unfreezenode")
        boltRedress()
        orc.enddialogue()
        boltYell("What do you think you're doing?!")
    end

    local target = orc.findclosest(20)
    if target ~= nil then 
        if (target.issexing or target.isfapping) and not orc.issexing then 
            if not orc.ifitemflag("OF-Bolt-Vanished", "1") then 

                boltYell("...Nope, I'm out.")

                orc.buff(orc, "Disappear", 0.8, 1)
                orc.consolecommand("oluacf OrcFollower,waitHere")
                orc.consolecommand("batch nudgebwd;nudgebwd;nudgebwd;nudgebwd;")
                orc.setitemflag("OF-Bolt-Vanished", "1")

                OFDebug("filterBolt", "You scared off Bolt! D:")
            end
        else 
            if not orc.ifitemflag("OF-Bolt-Vanished", "0") then 

                boltYell("...Are you finished?")

                orc.buff(orc, "Appear", 0.8, 1)
                orc.consolecommand("oluacf OrcFollower,follow")
                orc.setitemflag("OF-Bolt-Vanished", "0")

                OFDebug("filterBolt", "Bolt decided the coast was clear...")
            end
        end
    end



    if orc.isfapping then 
        orc.fapstop()
        boltRedress()
        boltYell("I'm not doing that!")
    end

    if orc.genitalsconcealed == false then 
        boltRedress() 
        boltYell("Stop that!")
    end

end

function boltRedress()

    OFDebug("boltRedress", "Bolt doesn't like being nude. Redressing...")

    --Re-dress bolt after he was forced to have sex
    orc.consolecommand("batch target @self;give 72;give 19;give 74")
end

function boltYell(message)

    -- Have Bolt complain if the player makes him uncomfortable.

    if not boltYelling then 

        orc.consolecommand("infodialogue Bolt: \"" .. message .. "\"")
        boltYelling = true
        orc.luaiterator(SCRIPT_NAME, "boltYellCooldown", orc.infinity)

    end

end

function boltYellCooldown() 

    if yellTimer < YELL_WAIT then 
        yellTimer = yellTimer + orc.game.deltatime
        return
    else 
        yellTimer = 0
        boltYelling = false
        orc.consolecommand("oluaria " .. SCRIPT_NAME .. ",boltYellCooldown")
    end

end

function onCurse()

    --[[
        Restore his speech when he gets hit by the curse, then change it back to the 
        Drone's dialogue when he gets geniefied...
    ]]

    if orc.corruption > 0 then 

        --If this orc is cursed but not yet geniefied, restore speech.
        if orc.corruption < 3 then 

            if currentSpeech ~= "normal" then 
                orc.consolecommand("modspeech Orc_Follower/Diag-LoreNPC")
                currentSpeech = "normal"
                OFDebug("onCurse", "Lore NPC Corrupted. Forced dialogue back to Follower Menu")
            end

        --else if they have been geniefied make them use the drone's dialogue
        else

            if orc.hasluascript("genieagent") and currentSpeech ~= "drone" then 
                orc.consolecommand("modspeechrestore")
                currentSpeech = "drone"
                OFDebug("onCurse", "Lore NPC became a Drone. Restoring original speech")
            end

        end

    else 

        --If their speech was previously change to the drone, restore it.
        if currentSpeech == "drone" then 
            orc.consolecommand("modspeech Orc_Follower/Diag-LoreNPC")
            currentSpeech = nil
            OFDebug("onCurse", "Lore NPC was purified. Forced dialogue back to Follower Menu")
        end

    end
    
end

-- Print debugging messages out to the console
function OFDebug(functionName, text) 
    orc.debuglog(SCRIPT_NAME .. ", " .. functionName .. "() on " .. orc.orcname .. ":\n\t" .. text)
end
