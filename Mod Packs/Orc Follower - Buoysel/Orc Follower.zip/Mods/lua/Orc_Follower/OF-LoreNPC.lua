--[[
    Grants Lore NPCs Follower Dialogue
]]

--Shorthand
local SCRIPT_NAME = "Orc_Follower/OF-LoreNPC"

--Cooldown for when Bolt complains
local YELL_WAIT = 2
local yellTimer = 0
local boltYelling = false

function start()

    OFDebug("start", "Recruiting Lore NPC...")

    recruitLoreNPC()

    --Add some Bolt-specific filters
    if orc.orcname == "Bolt" then 
        orc.setitemflag("OF-Bolt-Vanished", "0")
        orc.luaiterator(SCRIPT_NAME, "filterBolt", orc.infinity)
    end

end

function recruitLoreNPC()

    OFDebug("recruitLoreNPC", "Replacing speech with follower dialogue")

    -- Injects the Lore NPC with Follower dialogue and replaces their regular speech.
    orc.consolecommand("modspeech Orc_Follower/Diag-LoreNPC")
end

function dismissLoreNPC()

    OFDebug("dismissLoreNPC", "Restoring vanilla dialogue")

    -- Restore the Lore NPC's original speech
    orc.consolecommand("modspeechrestore")

    -- Remove the special Lore NPC flags
    orc.consolecommand("removescriptflag OF-LoreNPCIs")
    orc.consolecommand("removescriptflag OF-Bolt-Vanished")
end

function filterBolt()

    --Do not allow Bolt to engage in any sex acts unless he is corrupted.
    if orc.corruption > 0 then 
        return 
    end

    if orc.issexing then 
        orc.endsex()
        orc.consolecommand("unfreezenode")
        boltRedress()
        orc.enddialogue()
        boltYell("What do you think you're doing?!")
    end

    local target = orc.findclosest(20)
    if target ~= nil then 
        if (target.issexing or target.isfapping) and not orc.issexing then 
            if not orc.ifitemflag("OF-Bolt-Vanished", "1") then 

                boltYell("...Nope, I'm out.")

                orc.buff(orc, "Disappear", 0.8, 1)
                orc.consolecommand("oluacf OrcFollower,waitHere")
                orc.consolecommand("batch nudgebwd;nudgebwd;nudgebwd;nudgebwd;")
                orc.setitemflag("OF-Bolt-Vanished", "1")

                OFDebug("filterBolt", "You scared off Bolt! D:")
            end
        else 
            if not orc.ifitemflag("OF-Bolt-Vanished", "0") then 

                boltYell("...Are you *quite* finished?")

                orc.buff(orc, "Appear", 0.8, 1)
                orc.consolecommand("oluacf OrcFollower,follow")
                orc.setitemflag("OF-Bolt-Vanished", "0")

                OFDebug("filterBolt", "Bolt decided the coast was clear...")
            end
        end
    end

    if orc.genitalsconcealed == false then 

        if orc.isfapping then 
            orc.fapstop()
            boltYell("I'm not doing that!")
        else 
            boltYell("Stop that!")
        end
        boltRedress() 
    end

    -- Have Bolt wanter off instead of sexing or foreplaying
    if orc.ifitemflag("OF-RelaxState", "SEXING") or 
       orc.ifitemflag("OF-RelaxState", "FOREPLAYING") then 
       orc.setitemflag("OF-RelaxState", "WANDERING")
    end

end

function boltRedress()

    OFDebug("boltRedress", "Bolt doesn't like being nude. Redressing...")

    --Re-dress bolt after he was forced to have sex
    orc.consolecommand("batch target @self;give 72;give 19;give 74")
end

function boltYell(message)

    -- Have Bolt complain if the player makes him uncomfortable.

    if not boltYelling then 

        orc.say(message)
        boltYelling = true
        orc.luaiterator(SCRIPT_NAME, "boltYellCooldown", orc.infinity)

    end

end

function boltYellCooldown() 

    if yellTimer < YELL_WAIT then 
        yellTimer = yellTimer + orc.game.deltatime
        return
    else 
        yellTimer = 0
        boltYelling = false
        orc.consolecommand("oluaria " .. SCRIPT_NAME .. ",boltYellCooldown")
    end

end

-- Print debugging messages out to the console
function OFDebug(functionName, text) 
    orc.debuglog(SCRIPT_NAME .. ", " .. functionName .. "() on " .. orc.orcname .. ":\n\t" .. text)
end
