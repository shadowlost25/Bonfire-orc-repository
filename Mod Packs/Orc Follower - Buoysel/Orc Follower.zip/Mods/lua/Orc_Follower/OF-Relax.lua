--[[
    This script will let the followers wander the scene on their
    own within a certain range of the player. Actions will be 
    decided based on intervals
]]

local player = orc.game.orcfromcommandname("@playername")

--Shorthand
local SCRIPT_NAME = "Orc_Follower/OF-Relax"

--Wandering Range
local MAX_PLYR_DIST = 40
local MAX_WANDER_DIST = 7.5

--Wander intervals 
local activityInterval = orc.game.randomint(0,25+1)
local activityTimer = 0

--If an follower is attempting to have sex with another follower 
local SEX_ATTEMPTS_MAX = 3 
local sexAttempts = 0

local FOREPLAY_ATTEMPTS_MAX = 3
local foreplayAttempts = 0

--Targeting for sex and foreplay
local nextClosest = orc

local emoteStarted = false
local madeToWalk = false

function startRelaxing() 

    orc.setitemflag("OF-FollowState", "RELAXING")
    orc.luaiterator(SCRIPT_NAME, "relax", orc.infinity)

    OFDebug("startRelaxing", "Relaxing iterator started")

end 

function stopRelaxing()

    cancelActions()
    orc.remiterators(SCRIPT_NAME, "relax") -- Cancel the relax script, if running
    OFDebug("stopRelaxing", "Relaxing iterator stopped.")
end

function relax() 

    --If the orc isn't actually in the relaxed state, then don't execute this script. 
    if not orc.ifitemflag("OF-FollowState", "RELAXING") then 
        return
    end

    --Used to check orc's current relaxing activity
    if not orc.hasitemflag("OF-RelaxState", "STANDING") then 
        orc.setitemflag("OF-RelaxState", "STANDING")
    end

    --Make sure the player exists in the scene. 
    if player == nil then 
        OFDebug("checkPlayer", "Player not found, attempting to find them.")
        player = orc.game.orcfromcommandname("@playername")
        return 
    end

    --If the player is interacting with the follower in some capacity, 
    --force them back into the Standing State and don't do anything. 
        --[[THIS MIGHT BE THE REASON WHY FAPPING BREAKS]]
    ---[[
    -- if this orc is talking then 
    if orc.istalking then 
        --     Set the relax state back to standing if it isn't already
        --     reset the activity timer 
        --     return from this function 
        if not orc.ifitemflag("OF-RelaxState", "STANDING") then 
            orc.setitemflag("OF-RelaxState", "STANDING")
            OFDebug("relax", "Follower is speaking with the player. Resetting to standing.")
        end
        activityTimer = 0
        return
    -- else if this orc is busy and the player is busy 
    elseif orc.isbusy and player.isbusy then 
        
        -- ...if this orc isn't fapping, or isn't doing the floorfap animation then...
        local fappingActs = {[4] = true, [7] = true, [10] = true}
        if not orc.isfapping or fappingActs[orc.sextype] ~= true then
            
            -- if this orc's objective is the player, and the player's objective is this orc then 
            if orc.orcobjective == player and player.orcobjective == orc then

                -- if the distance between this orc and the player is less than 1.18m then 
                if orc.game.distancebetweenorcs(orc, player) < 1.18 then 

                    --I can hopefully assume the player is foreplaying with this other orc... right?
                    if not orc.ifitemflag("OF-RelaxState", "STANDING") then 
                        orc.setitemflag("OF-RelaxState", "STANDING")
                        OFDebug("relax", "Follower is probably foreplaying with the player. Resetting to standing.")
                    end
                    activityTimer = 0
                    return
                end
            
            end
        end
    end
    --]]

    -- If the orc isn't busy wandering and they're within the player's range, do an activity
    if not ifWithinPlayerRange() then 
        return
    end

    if orc.ifitemflag("OF-RelaxState", "STANDING") then 
        selectAction()

    elseif orc.ifitemflag("OF-RelaxState", "SEXING") then
        startSex()

    elseif orc.ifitemflag("OF-RelaxState", "FOREPLAYING") then
        findForeplayPartner()

    elseif orc.ifitemflag("OF-RelaxState", "EMOTING") then
        randomEmote()

    elseif orc.ifitemflag("OF-RelaxState", "WANDERING") then
        wander()

    end

end 


function ifWithinPlayerRange()
    if not orc.busywalking and orc.game.distancebetweenorcs(orc,player) < MAX_PLYR_DIST then 
        return true

    -- If the orc is way too far from the player, then start following again
    elseif orc.game.distancebetweenorcs(orc,player) > 60 then 
        cancelActions()
        orc.luacallfunction("OrcFollower","follow")
        return false

    -- Somewhat stick to the player as they wander around
    elseif orc.game.distancebetweenorcs(orc,player) > MAX_PLYR_DIST then
        if not orc.isbusy then 
            orc.walk2orc(player,1,10,false)
            cancelActions()
        end

        return false
    end

    return false
end

function activityTimeExpired() 

    if activityTimer < activityInterval then 
        activityTimer = activityTimer + orc.game.deltatime
        return false
    else 
        activityTimer = 0
        activityInterval = orc.game.randomint(5,15+1)
        return true
    end

end

function selectAction()

    --Decide which activities to do.
    local tbl = {activityScale = math.random()}

    if setChance(tbl, 0.09) < 0 then
        if orc.meios < 8 then 
            OFDebug("selectAction", "Would sex or fap, but not enough meios.")
        else
            orc.setitemflag("OF-RelaxState", "SEXING")
            OFDebug("selectAction", "Sexing...")
        end

    elseif setChance(tbl, 0.11) < 0 then 
        orc.setitemflag("OF-RelaxState", "FOREPLAYING")
        OFDebug("selectAction", "Foreplaying...")

    elseif setChance(tbl, 0.30) < 0 then 
        orc.setitemflag("OF-RelaxState", "EMOTING")
        OFDebug("selectAction", "Emoting...")

    elseif setChance(tbl, 0.50) < 0 then 
        orc.setitemflag("OF-RelaxState", "WANDERING")
        OFDebug("selectAction", "Wandering...")

    end

end

function setChance(tbl, prcnt) 
    tbl.activityScale = tbl.activityScale - prcnt
    return tbl.activityScale
end

function wander() 

    --Wander around the scene.

    if madeToWalk then 

        if not activityTimeExpired() then 
            return  
        end

        if not orc.busywalking then 
            orc.setitemflag("OF-RelaxState", "STANDING")
        end

        madeToWalk = false
    else
        local walkCommmand = "walktoloc @self," .. getWalkLocation() .. ",5,1,false"
        orc.consolecommand(walkCommmand)
        madeToWalk = true
    end

end 

function getWalkLocation()

    --[[ Calculates a random point from the orc's current 
        position to a random range within a certain radius.
    ]]
    
    local range = MAX_WANDER_DIST * math.sqrt(math.random())
    local theta = math.random() * 2 * math.pi

    local x = orc.positionx + range * math.cos(theta)
    local z = orc.positionz + range * math.sin(theta)
    return x .. "," .. orc.positiony .. "," .. z

end

function randomEmote() 
    
    --The follower will randomly pick a emote
    --Create a flag to determine whether to cancel emote or swap to a new one.

    if emoteStarted then 

        if not activityTimeExpired() then 
            return  
        end

        local tbl = {activityScale = math.random()}
        if setChance(tbl, 0.15) < 0 then 
            --Resume current emote.
            return 
        end

        orc.consolecommand("forceanim Armature|Idle1")
        orc.consolecommand("emote stand")
        orc.setitemflag("OF-RelaxState", "STANDING")
        emoteStarted = false

    else 

        local emotes = {
            "dance", "dance2", "dance3", "dance4", "dance5",
            "dance5b", "dance6", "dance7", "bkiss1", "glee", "flex", "shrug", 
            "lay", "lay2", "lol", "sit", "roar"
        }
    
        local emoteIndex = orc.game.randomint(1, #emotes + 1)
        
        OFDebug("randomEmote", orc.orcname .. " started " .. emotes[emoteIndex])
        orc.consolecommand("emote " .. emotes[emoteIndex])
    
        emoteStarted = true

    end

end

function findForeplayPartner()

    --Find a partner for foreplaying
    if orc.isbusy then 

        if not activityTimeExpired() or orc.meios < 8 then 
            return 
        end

        local tbl = {activityScale = math.random()}
        if setChance(tbl, 0.5) > 0 then 
            --Resume foreplaying
            return 
        end

        --Set the foreplaying target to standing, too.
        orc.consolecommand("oldforeplaystop")
        orc.setitemflag("OF-RelaxState", "STANDING")
        if orc.orcobjective ~= nil then 
            orc.orcobjective.setitemflag("OF-RelaxState", "STANDING")
        end

    else 
        if foreplayAttempts < FOREPLAY_ATTEMPTS_MAX then
            -- Check if the current target is a valid partner
            if isValidPartner(nextClosest) == false then 
                OFDebug("findForeplayPartner", orc.orcname .. " tried to target " .. nextClosest.orcname .. " but they were unavailable. Finding next target... ")
                nextClosest = orc.findnextclosest(12, nextClosest)
                foreplayAttempts = foreplayAttempts + 1
                return
            end

            if orc.game.distancebetweenorcs(orc, nextClosest) > 1.5 then 
                orc.walk2orc(nextClosest, 1, 10, true)
                nextClosest.walk2clear()

                OFDebug("findForeplayPartner", "Walking closer to target")
            else
                orc.orcobjective = nextClosest
                nextClosest.orcobjective = orc

                orc.tp2pos(nextClosest.positionx, nextClosest.positiony, nextClosest.positionz)
                orc.consolecommand("batch target @self;nudgefwd;turnback;oldforeplay")

                OFDebug("findForeplayPartner", "Attempting to start foreplay. Objective is " .. orc.orcobjective.orcname)

                if orc.isbusy then 
                    nextClosest.setitemflag("OF-RelaxState", "FOREPLAYING")
                    OFDebug("findForeplayPartner", "Flags have been set.")

                    foreplayAttempts = 0

                end

            end
        else 

            --if unable to find a foreplay partner, do something else. 
            orc.setitemflag("OF-RelaxState", "STANDING")
            foreplayAttempts = 0

        end
    end
end

function startSex() 
    
    --Attempt to find a sex partner, or fap by themself
    if orc.issexing or orc.isfapping then 

        -- Attempt to cancel sex act

        if not activityTimeExpired() then 
            return 
        end

        if orc.meios < 8 then 

            if orc.isfapping then 
                orc.fapstop()
            elseif orc.issexing and not orc.cumming then 
                orc.sexend()
            end
            orc.setitemflag("OF-RelaxState", "STANDING")
            OFDebug("cancelActions", "Attempt to end fap or floor fap")

        else

            -- For other cases where scenes either have no AI or don't have an orgasm yet, just end them.
            local tbl = {activityScale = math.random()}
            if setChance(tbl, 0.15) > 0 then 
                --Resuming current sex action
                return 
            end

            OFDebug("cancelActions", "Ending sex early.")
            orc.sexend()
            
            orc.setitemflag("OF-RelaxState", "STANDING")
            if orc.orcobjective ~= nil then 
                orc.orcobjective.setitemflag("OF-RelaxState", "STANDING")
            end

        end

    else

        if sexAttempts < SEX_ATTEMPTS_MAX then 
        
            -- Check if the current target is a valid partner
            if isValidPartner(nextClosest) == false then 
                OFDebug("startSex", orc.orcname .. " tried to target " .. nextClosest.orcname .. " but they were unavailable. Finding next target... ")
                nextClosest = orc.findnextclosest(12, nextClosest)
                sexAttempts = sexAttempts + 1
                return
            end
    
            if orc.game.distancebetweenorcs(orc, nextClosest) > 1.5 then 
                orc.walk2orc(nextClosest, 1, 10, true)
                nextClosest.walk2clear()
                OFDebug("startSex", "Walking closer to target")
            else
    
                local sexActs = {
                    "ssa1", "spr1", "sco1", "sc69"
                }
                local sexIndex = orc.game.randomint(1, #sexActs + 1)
    
                orc.orcobjective = nextClosest
                nextClosest.orcobjective = orc
    
                nextClosest.consolecommand(sexActs[sexIndex])
                orc.tp2pos(nextClosest.positionx, nextClosest.positiony, nextClosest.positionz)
                orc.consolecommand("joinsex")
        
                OFDebug("startSex", "Attempting to start sex. Objective is " .. orc.orcobjective.orcname)
        
                if orc.issexing then 
                    nextClosest.setitemflag("OF-RelaxState", "SEXING")
                    OFDebug("startSex", "Flags have been set.")
    
                    sexAttempts = 0
        
                end
        
            end
    
        else 
    
            --Unable to find an available partner, so fap by yourself.
            local sexActs = {
                "fap", "floorfap1"
            }
            local sexIndex = orc.game.randomint(1, #sexActs + 1)
    
            orc.consolecommand(sexActs[sexIndex])
    
            if orc.isfapping then 
                OFDebug("startSex", orc.orcname.. " is fapping alone")
                sexAttempts = 0
            end
        end
        
    end
end 

function isValidPartner(target) 

    if target == nil then 
        OFDebug("isValidPartner", orc.orcname .. " targeted a nil orc")
        nextClosest = orc
        return false
    end

    if target == orc then 
        OFDebug("isValidPartner", orc.orcname .. " targeted self")
        return false
    end

    if target.istheplayer then 
        OFDebug("isValidPartner", orc.orcname .. " targeted player")
        return false
    end

    if target.isbusy then 
        OFDebug("isValidPartner", orc.orcname .. "'s targeted " .. target.orcname .. " but they are busy.")
        return false
    end

    if target.ifitemflag("OF-FollowState", "RELAXING") == false then
        OFDebug("isValidPartner", orc.orcname .. "'s target is not another follower")
        return false 
    end

    if orc.ifitemflag("OF-RelaxState", "SEXING") and target.meios < 8 then 
        OFDebug("isValidPartner", orc.orcname .. "'s target does not have enough meios for sex")
        return false
    end

    OFDebug("isValidPartner", orc.orcname .. " is attempting to target " .. target.orcname)

    return true
end

function cancelActions()
    orc.fapstop()
    orc.consolecommand("oldforeplaystop")
    orc.sexend()
    orc.consolecommand("forceanim Armature|Idle1")
    orc.consolecommand("emote stand")
    orc.setitemflag("OF-RelaxState", "STANDING")

end

function OFDebug(functionName, text) 
    -- Print debugging messages out to the console
    orc.debuglog(SCRIPT_NAME .. ", " .. functionName .. "() on " .. orc.orcname .. ":\n\t" .. text)
end