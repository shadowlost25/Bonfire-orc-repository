--[[
    Spawns or removes a folllower's personal bed for sex.
]]

--OrcBed name
local stonebed = orc.orcname .. "Bed"

--Shorthand
local SCRIPT_NAME = "Orc_Follower/OF-BedSpawner"

function despawnBedPostSex() 
    --Will despawn the follower's bed if the player is no longer having sex with them.
    if not orc.issexing then 
        removeBed()
        orc.consolecommand("oluaria ".. SCRIPT_NAME ..",despawnBedPostSex")
    end
end

function removeBed()

    OFDebug("removeBed", "Removing " .. orc.orcname .. "'s bed.")

    orc.consolecommand("asset " .. stonebed)
    if orc.game.consoleasset ~= nil then
        orc.consolecommand("assetclear " .. stonebed)
    end

end

function spawnBed() 

    --Don't spawn a bed if we're in the Inn, BathHouse, or Library
    if inInvalidLocation() then 
        return 
    end

    local xyzcord = getCoords()
    local xyzrot = getRotation()

    OFDebug("spawnBed", "Spawning " .. orc.orcname .. "'s bed.")

    orc.consolecommand("asset World/Props/Prefabs/StoneCircleLite")
    orc.consolecommand("batch assetnameset " .. stonebed ..";asset " .. stonebed)
    orc.consolecommand("assetpos " .. xyzcord .. "," .. xyzrot .. ",false")
    orc.consolecommand("assetrefrotset")

end

function inInvalidLocation() 

    local player = orc.game.orcfromcommandname("@playername")
    local BED_DISTANCE = 13

    -- Don't spawn the bed in the "Indoor" scenes.
    if orc.game.sceneis("Inn1") or 
       orc.game.sceneis("BathHouse") or 
       orc.game.sceneis("Library") then 

        OFDebug("inInvalidLocation", "We are in " .. orc.game.nextscene .. ". Skipping the bed.")

        return true 
    else

        -- Don't spawn a bed when standing next to the islands' bed.
        if orc.game.sceneis("Sea1") and distanceFromBed(loreBeds[9], player) < BED_DISTANCE then 
            OFDebug("inInvalidLocation", "We are too close to a vanilla bed. Skipping the bed.")
            return true
        end 

        --Don't spawn the bed when standing next to a bed already.
        for i=1, (#loreBeds-1) do 
            if orc.game.sceneis("Outback1") and distanceFromBed(loreBeds[i], player) < BED_DISTANCE then 
                OFDebug("inInvalidLocation", "We are too close to a vanilla bed. Skipping the bed.")
                return true
            end
        end

    end

    return false

end

function getCoords() 
    --Orc's Current Coordinates
    local xyzcord = orc.positionx .. "," .. 
                    (orc.positiony - 2.5) .. "," .. 
                    orc.positionz

    return xyzcord
end

function getRotation()
    --For now this is just to fill in the rotation argument of the 
    --assetpos command.     
    local xyzrot = 0 .. "," ..      --x
                   0 .. "," ..      --y
                   0                --z
    orc.consolecommand("refrot")

    return xyzrot
end

-- Print debugging messages out to the console
function OFDebug(functionName, text) 
    orc.debuglog(SCRIPT_NAME .. ", " .. functionName .. "() on " .. orc.orcname .. ":\n\t" .. text)
end

--Check the distance between this orc and the stone bed.
function distanceFromBed(bed, player)
    return math.sqrt( 
                      (bed.x - player.positionx)^2 +
                      (bed.y - player.positiony)^2 +
                      (bed.z - player.positionz)^2 
                    )
end

--[[
    Coordinates for the lore beds. Do not spawn a bed within a certain range of these
    locations.
]]

loreBeds = {
    {
        bedName = "Erol",
        x = 0.09659444,
        y = 174.2097,
        z = 0.06790632
    },
    {
        bedName = "Celik",
        x = 281.295,
        y = 191.7025,
        z = 162.262
    },
    {
        bedName = "Oriol",
        x = -0.04951471,
        y = 191.703,
        z = 324.874
    },
    {
        bedName = "Bo",
        x = -281.3914,
        y = 191.7028,
        z = 162.4696
    },
    {
        bedName = "Durian",
        x = 281.4181,
        y = 191.7029,
        z = -162.4744
    },
    {
        bedName = "Bolt",
        x = 0.231703,
        y = 191.6908,
        z = -325.3836
    },
    {
        bedName = "Aintzira",
        x = 281.2983,
        y = 191.7023,
        z = -162.637
    },
    {
        bedName = "Cave",
        x = -24.70188,
        y = 149.3631,
        z = 146.8641
    },
    {
        bedName = "Beach",
        x = -12.6544,
        y = 3.845024,
        z = -30.2266
    }
}