--[[ 
    Orc Follower -- by Buoysel
    
    This script is the public interface for easily giving commands to your followers
    through NPC Dialogue, scrolls, or through the command console.

    The actual implementation of these functions can be found within the
    "Orc_Follower/" folder of your Lua directory.

    For more information on how to use this mod, please refer to the wiki
    at: https://bonfire-wiki.net/index.php/Orc_Follower

    Credits:
        -Hogswild Prasetto:
            - For the creation of Bonfire, testing, offering feedback, script
            writing, and adding new Lua features and console commands to make 
            this mod possible

        -Testers:
            - astrobrite, BruBearBrown, Garent, Halox, Leo the Lion, Orzok

    Important Data Flags and their possible values. When referencing 
    these states in your own scripts and NPCs, remember they are
    cASe sEnSItiVE:

        - OF-FollowState
            * FOLLOWING 
            * WAITING
            * DISMISSED
            * RELAXING

        - OF-RelaxState
            * STANDING
            * SEXING
            * FOREPLAYING
            * EMOTING
            * WANDERING

]]

-- Shorthand
local SCRIPT_NAME = "OrcFollower"
local API_CALL = "oluacf Orc_Follower/OF-API,"

local dependencies = {
    "Orc_Follower/OF-API",
    "Orc_Follower/OF-FollowPlayer",
    "Orc_Follower/OF-Relax",
    "Orc_Follower/OF-SceneSpawn",
    "Orc_Follower/OF-BedSpawner",
    "Orc_Follower/OF-PlayerControls",
    "Orc_Follower/OF-DialogueChecks"
}

-- Re-add the follower data flags if they're missing for some reason.
if not orc.hasitemflag("OF-FollowState", "@any") then 
    orc.setitemflag("OF-FollowState", "DISMISSED")
end

function start() 

    -- Initialization

    if filters() then 
        return 
    end

    OFDebug("start", "Installing " .. SCRIPT_NAME .. " on " .. orc.orcname)
  
    orc.setitemflag("OF-FollowState", "DISMISSED")

    orc.consolecommand("forceanim Armature|Idle1")

    for i=1, #dependencies do 
        orc.consolecommand("batch oluarem ".. dependencies[i] ..";oluainj ".. dependencies[i])
    end

    if orc.iscorechr then 
        orc.consolecommand("batch oluarem Orc_Follower/OF-LoreNPC;oluainj Orc_Follower/OF-LoreNPC")
        orc.setitemflag("OF-LoreNPCIs", orc.orcname)
    end

    --Add the click choices
    disableClickchoice()
    enableClickchoice()
    
end

function onscenechanged()

    --Warn the player they still have the mod install on their person.
    if orc.istheplayer then 
        orc.consolecommand("omen Orc_Follower/Omen-PlayerWarning")
        OFDebug("onscenechanged", "Prompting player to uninstall mod on their character.")
    end
end

function follow() 

    -- The target will follow you around

    if filters() then return end
    orc.consolecommand(API_CALL .. "follow")
end

function waitHere()

    -- The target will stop following and wait at their location.

    if filters() then return end
    orc.consolecommand(API_CALL .. "waitHere")
end

function relax() 

    -- The target will relax within range of the player

    if filters() then return end 
    orc.consolecommand(API_CALL .. "relax")
end

function moveToLocation()

    -- A rune will appear and allow you to direct the target to move to a specific spot.

    if filters() then return end 
    orc.consolecommand(API_CALL .. "moveToLocation")
end

function dismiss()

    -- The target will stop following and warp back to their original spawn point.

    if filters() then return end
    orc.consolecommand(API_CALL .. "dismiss")

    --Lore NPCs will restore their original dialogue
    if orc.iscorechr and orc.ifitemflag("OF-FollowState", "DISMISSED") then 
        orc.consolecommand("oluacf Orc_Follower/OF-LoreNPC,dismissLoreNPC")
        remove()
    end
end

function openInventory()

    -- Open's the follower's inventory.

    if filters() then return end
    orc.consolecommand(API_CALL .. "openInventory")
end

function dance()

    --The orc will do a random dance

    if filters() then return end
    orc.consolecommand(API_CALL .. "dance")
end

--[[ 
    NOTE: Any of the sex commands will call spawnBed and removeBed
    automatically. Calling this manually is unnecessary unless 
    you're starting sex through Bonfire's built-in 
    QuickInteractions Action in Dialogue instead of this API.
]]
function spawnBed()

    --The orc will spawn a bed under their feet.

    if filters() then return end
    orc.consolecommand(API_CALL .. "spawnBed")
end

function removeBed()

    --The orc will delete their spawned bed.

    if filters() then return end
    orc.consolecommand(API_CALL .. "removeBed")
end

function enableClickchoice() 
  
    -- Adds more options to the interaction ring.

    orc.consolecommand("clickchoice Kiss,batch target @playername;orcinterestset @playerinterest,@playername;oldforeplay")
    orc.consolecommand("clickchoice Dance,batch target @playerinterest;oluacf OrcFollower,dance;targetclear")
end

function disableClickchoice() 

    -- Deletes options from the interaciton ring.

    orc.consolecommand("clickchoicedel Kiss")
    orc.consolecommand("clickchoicedel Dance")
end

function sca1Top()
    
    -- Spawns a bed and starts a Doggy-style animation where you top

    if filters() then return end
    orc.consolecommand(API_CALL .. "sca1Top")
end

function sca1Bottom()

    -- Doggy-style animation, but you bottom.

    if filters() then return end
    orc.consolecommand(API_CALL .. "sca1Bottom")
end

function ssa1Top() 

    -- Standing Doggy-style animation where follower invites you to top.
    
    if filters() then return end 
    orc.consolecommand(API_CALL .. "ssa1Top")
end

function ssa1Bottom()

    -- Standing Doggy-style, but you invite the follower
    
    if filters() then return end 
    orc.consolecommand(API_CALL .. "ssa1Bottom")
end

function sca2Top()
    
    -- Spawns a bed and starts a Missionary animation where you top

    if filters() then return end
    orc.consolecommand(API_CALL .. "sca2Top")
end

function sca2Bottom()

    -- Missionary, but you bottom.
    
    if filters() then return end
    orc.consolecommand(API_CALL .. "sca2Bottom")
end

function spr1Top() 

    -- Cowgirl 
    
    if filters() then return end 
    orc.consolecommand(API_CALL .. "spr1Top")
end 

function spr1Bottom() 

    -- Cowgirl, but you bottom. 

    if filters() then return end 
    orc.consolecommand(API_CALL .. "spr1Bottom")

end

function sco1Give()

    -- Gives your follower a blowjob
        
    if filters() then return end
    orc.consolecommand(API_CALL .. "sco1Give")
end

function sco1Receive()

    -- Receive a blowjob from your follower

    if filters() then return end
    orc.consolecommand(API_CALL .. "sco1Receive")
end

function sc69Start()

    -- Starts 69

    if filters() then return end
    orc.consolecommand(API_CALL .. "sc69Start")
end

function filters()

    -- Prevent OF from being used under certain circumstances

    if orc.game.networked then 
        OFDebug("filters", "Filter condition triggered: Player attempted to use script online.")
        orc.consolecommand("infodialogue The Orc Follower mod cannot be used online.")
        remove()
        return true
    else 
        if orc.istheplayer then 
            OFDebug("filters", "Filter condition triggered: OF injected on player character.")
            orc.consolecommand("omen Orc_Follower/Omen-PlayerWarning")

            --Deactivate the self-destruct
            orc.consolecommand("invokedelay 1")
            orc.consolecommand("invoke batch target @playername;oluaria Orc_Follower/OF-PlayerControls,selfDestruct;targetclear")
        end

        if orc.corruption >= 3 then 
            OFDebug("filters", "Filter condition triggerd: Orc is corrupted and is too distracted to follow orders!")
            orc.say("Can't... focus... so... horny...")
            return true
        end

        if orc.immutable then 
            OFDebug("filters", "Filter condition triggered: Attempted to recruit an immutable NPC.")
            orc.consolecommand("infodialogue This Orc/Genie cannot be recruited.")
            remove()
            return true
        end
    end

    return false
end

function remove()

    --[[ DELETES THE ORC FOLLOWER SCRIPT AND ITS DEPENDENCIES ]]

    OFDebug("remove", "Uninstalling OF from " .. orc.orcname)

    --[[ 
        Dismissed Lore NPCs will call the remove() function
        to delete the mod entirely. So don't call the
        dismiss() function again. 
    ]]

    if (not orc.iscorechr and not orc.immutable) and not orc.istheplayer then 
        dismiss()
    end

    disableClickchoice()

    orc.consolecommand("removescriptflag OF-FollowState")
    orc.consolecommand("removescriptflag OF-RelaxState")

    for i=1, #dependencies do 
        orc.consolecommand("oluarem ".. dependencies[i])
    end

    if orc.iscorechr then 
        orc.consolecommand("oluarem Orc_Follower/OF-LoreNPC")
    end

    orc.consolecommand("oluarem OrcFollower")
end

function OFDebug(functionName, text) 
    -- Print debugging messages out to the console
    orc.debuglog(SCRIPT_NAME .. ", " .. functionName .. "() on " .. orc.orcname .. ":\n\t" .. text)
end