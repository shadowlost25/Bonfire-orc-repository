The Demonic Contract v0.44.4.1
Refer to https://hogswilds-bonfire.fandom.com/wiki/The_Demonic_Contract for more information and hints.
