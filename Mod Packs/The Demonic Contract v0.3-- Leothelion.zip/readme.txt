The Demonic Contract v0.40.0.3
> This is a fantasy story mod for Bonfire created by Leothelion.
> Don't play it if you don't like the following themes: interspecies romance (humans/orcs/demons), speciesism, size difference, small penis humiliation, cum drinking, dad and son, sex slavery, rape, gay sex with straight men.
> Copy the files into C:\Users\<UserName>\AppData\LocalLow\Prasetto\Bonfire.
> Select the profile Kayden; he's the main character, a human. You could also use your own orc profile, but for role-playing purpose he should look like a human.
> Double check that all of the mod NPCS are switched on in the NPC Manager.
> For role-playing purpose, don't access the inventory or use console commands.
> If the day-night cycle makes the scene really dark, try the Lay Down and Skip Time button beside the Save button at the bottom of the screen.
> You can step outside of portals, it's part of the story.
> For role-playing purpose, when you give an orc a blowjob, go all the way deep in on him.
> When an orc is in control of fucking, just let him do his thing. He'll cum by himself after he feels real good.
> You don't always have to follow what the NPCs tell you to do. Try talking to different people in different orders. You might get different outcomes! You would have to play the story a couple of times to get all the dialogues and paths.
> The story currently ends at the bath house but isn't completed yet, more to come in the future!